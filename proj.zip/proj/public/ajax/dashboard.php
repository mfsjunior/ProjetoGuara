<?php

require_once '../../app/core/Database.php';
require_once '../../app/models/DashboardModel.php';


$database = new Database();
$db = $database->getConnection();


$dashboardModel = new DashboardModel($db);


$userCount = $dashboardModel->countUsers();
$supplierCount = $dashboardModel->countSuppliers();
$clientCount = $dashboardModel->countClients();


echo json_encode([
    'userCount' => $userCount,
    'supplierCount' => $supplierCount,
    'clientCount' => $clientCount
]);
?>
