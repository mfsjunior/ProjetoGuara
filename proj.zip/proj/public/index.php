<?php
// Requerendo a conexão com o banco e o controlador do Dashboard
require_once '../app/Lib/Database.php';
require_once '../app/controllers/DashboardController.php';

// Criar a conexão com o banco de dados
$database = new Database();
$db = $database->getConnection();

// Instanciar o controlador do dashboard
$controller = new DashboardController($db);

// Chamar o método index() para exibir o dashboard
$controller->index();
?>
