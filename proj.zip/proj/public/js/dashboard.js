// Função para buscar as contagens de usuários, fornecedores e clientes via AJAX
function loadDashboardData() {
    // Fazendo uma requisição AJAX para o servidor
    fetch('ajax/dashboard.php')
        .then(response => response.json())  // Espera o servidor retornar um JSON
        .then(data => {
            // Atualiza os valores na página com os dados retornados
            document.getElementById('userCount').textContent = data.userCount;
            document.getElementById('supplierCount').textContent = data.supplierCount;
            document.getElementById('clientCount').textContent = data.clientCount;
        })
        .catch(error => {
            console.error('Erro ao carregar os dados do dashboard:', error);
        });
}

// Carregar os dados assim que a página for carregada
window.onload = function() {
    loadDashboardData();
};