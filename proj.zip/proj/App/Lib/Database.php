<?php
// app/core/Database.php

class Database {
    private $host = 'localhost';
    private $db_name = 'nome_do_banco';  // Alterar para o nome do seu banco de dados
    private $username = 'usuario';       // Alterar para o usuário do seu banco
    private $password = 'senha';         // Alterar para a senha do seu banco
    private $conn;

    public function getConnection() {
        $this->conn = null;

        try {
            $this->conn = new PDO("mysql:host=" . $this->host . ";dbname=" . $this->db_name, 
                                  $this->username, 
                                  $this->password);
            $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $exception) {
            echo "Erro na conexão: " . $exception->getMessage();
        }

        return $this->conn;
    }
}
?>
