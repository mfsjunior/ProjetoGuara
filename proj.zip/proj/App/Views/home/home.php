
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="public/css/dashboardstyles.css">
    <script>
        function updateCounter(id) {
            const counterElement = document.getElementById(id);
            const currentCount = parseInt(counterElement.innerText);
            counterElement.innerText = currentCount + 1;
        }
    </script>
</head>

<body class="bg-gray-100">
  
<div class="grid" style="display: grid; grid-template-columns: 1fr; gap: 2rem; max-width: 1200px; margin: 0 auto;">
    <div style="background-color: white; padding: 1.5rem; border-radius: 0.5rem; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1); text-align: center;">
        <h3 style="color: #4B5563; margin-bottom: 0.5rem;">Total de Usuários</h3>
        <p id="userCounter" style="color: #3B82F6; font-size: 1.5rem; font-weight: bold;">0</p>
        <button onclick="updateCounter('userCounter')" style="margin-top: 1rem; background-color: #3B82F6; color: white; padding: 0.5rem 1rem; border-radius: 0.25rem; border: none; cursor: pointer;">
            Atualizar
        </button>
    </div>
    <div style="background-color: white; padding: 1.5rem; border-radius: 0.5rem; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1); text-align: center;">
        <h3 style="color: #4B5563; margin-bottom: 0.5rem;">Total de Fornecedores</h3>
        <p id="supplierCounter" style="color: #3B82F6; font-size: 1.5rem; font-weight: bold;">0</p>
        <button onclick="updateCounter('supplierCounter')" style="margin-top: 1rem; background-color: #3B82F6; color: white; padding: 0.5rem 1rem; border-radius: 0.25rem; border: none; cursor: pointer;">
            Atualizar
        </button>
    </div>
    <div style="background-color: white; padding: 1.5rem; border-radius: 0.5rem; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1); text-align: center;">
        <h3 style="color: #4B5563; margin-bottom: 0.5rem;">Total de Clientes</h3>
        <p id="clientCounter" style="color: #3B82F6; font-size: 1.5rem; font-weight: bold;">0</p>
        <button onclick="updateCounter('clientCounter')" style="margin-top: 1rem; background-color: #3B82F6; color: white; padding: 0.5rem 1rem; border-radius: 0.25rem; border: none; cursor: pointer;">
            Atualizar
        </button>
    </div>
</div>
<script>
    function updateCounter(counterId) {
        const counter = document.getElementById(counterId);
        const currentValue = parseInt(counter.textContent, 10);
        counter.textContent = currentValue + 1;
    }
</script>

</body>
</html>

