<?php

class DashboardModel {
    private $conn;

    public function __construct($db) {
        $this->conn = $db;
    }

    
    public function countUsers() {
        $query = "SELECT COUNT(*) as user_count FROM usuario";  
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result['user_count'];
    }

    
    public function countSuppliers() {
        $query = "SELECT COUNT(*) as supplier_count FROM fornecedores";  
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result['supplier_count'];
    }

    
    public function countClients() {
        $query = "SELECT COUNT(*) as client_count FROM clientes";  
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result['client_count'];
    }
}
?>
