<?php


require_once 'app/models/DAO/DashboardModel.php';

class DashboardController {
    private $dashboardModel;

    public function __construct($db) {
        $this->dashboardModel = new DashboardModel($db);
    }

   
    public function index() {
        $userCount = $this->dashboardModel->countUsers();
        $supplierCount = $this->dashboardModel->countSuppliers();
        $clientCount = $this->dashboardModel->countClients();

        
        require_once 'app/views/dashboard.php';
    }
}
?>

